import UIKit
import Foundation

public func example(of description: String,
                    action: () -> Void) {
  print("\n——— Example of:", description, "———")
  action()
}


example(of: "Playing with Swift") {
    var greeting = "Hello, playground"
    print(greeting)
    
}


example(of: "func example") {
    
    func add(_ a: Int, _ b: Int) -> Int {
        return a + b
    }
        
    let result = add(10, 20)
    
    print(result)
    
}
//closures,匿名函数
let add = {(a:Int,b:Int)->Int in
        return a+b
}
print(add(2,3))

let number=[1,4,2,3]
let sorted=number.sorted(by:{ (a:Int, b:Int)  -> Bool in
    return a<b
}
)
print(sorted)
//
let doubled = number.map{
    $0*2
}
print(doubled)

// 4. 逃逸闭包（异步回调）
//func fetchData(completion: @escaping (String) -> Void) {
//    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
//        completion("数据加载完毕")
//    }
//}

//func fetchData(completion:@escaping (String)->Void){
//    DispatchQueue.main.asyncAfter(deadline: .now() + 1){
//        completion("数据加载完毕")
//    }
//}
//



//定义的变量类型
//example(of: "Playing with Swift"){
//    var name = "zhangsan"
//    let pi = 3.1415926
//    var age: Int = 25
//    var price:Double=19.33
//    var isStudent:Bool=true
//    var greeting:String="nihao!"
//    let score = 98.5
//    let isAdmin = false
//}
//
//
////定义集合类型
//
//example(of: "Playing with Swift"){
//    var fruits=["apple","banana","origal"]
//    fruits.append("222")
//    print(fruits[0]);
//    fruits.remove(at: 1)
//}
////学习键值对
//example(of: "Playing with Swift"){
//    var person = [
//        "name":"lisi",
//        "age":"30",
//        "occupation":"gongcshi"
//    ]
//    person["email"]="li@example.com"
//    print(person["name"]!)
//    
//    var ids:Set<String> = ["ID001","ID002"]
//    ids.insert("ID004")
//    ids.contains("ID001")
//}
//
//example(of: "Playing with Swift"){
//    let temperature = 23
//    if temperature > 30{
//        print("天气炎热")
//    }else if temperature < 10{
//        print("天气寒冷")
//    }else{
//        print("温度适宜")
//    }
//}
//
//example(of: "Playing with Swift"){
//    let grade="0"
//    switch grade {
//    case "A":
//        print("优秀")
//    case "B","C":
//        print("良好")
//    default:
//        print("待提高")
//    }
//    var fruits = ["apple","banana"]
//    for furit in fruits {
//        print("水果：\(furit)")
//    }
//    var person = [
//        "name":"lisi",
//        "age":"30",
//        "occupation":"gongcshi"
//    ]
//    for (key,value) in person{
//        print("\(key):\(value)")
//    }
//    var count = 10
//    while count > 0{
//        print(count)
//        count -= 1
//    }
//}




